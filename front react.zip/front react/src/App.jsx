import { useState } from 'react';

export default function App() {
  const [page, setPage] = useState('login');

  if (page === 'dashboard') {
    return (
      <div style={{ backgroundColor: '#0d1117', color: 'white', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div style={{ backgroundColor: '#161b22', padding: 40, borderRadius: 12, width: 350, boxShadow: '0 0 10px rgba(0,0,0,0.5)' }}>
          <h1 style={{ textAlign: 'center', marginBottom: 10, fontSize: 24 }}>📊 Dashboard</h1>
          <p className="subtitle" style={{ textAlign: 'center', color: '#c9d1d9', fontSize: 14, marginBottom: 30 }}>Bem-vindo ao painel principal!</p>
          <button className="login-button" onClick={() => setPage('login')}>Sair</button>
        </div>
      </div>
    );
  }

  return (
    <div className="login-container">
      <h1>🔷 Finty</h1>
      <p className="subtitle">Comece sua jornada para uma melhor saúde financeira</p>

      <div className="tab-buttons">
        <button className="active">Entrar</button>
        <button>Registrar</button>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); setPage('dashboard'); }}>
        <label htmlFor="email">E-mail</label>
        <input type="email" id="email" placeholder="Digite seu e-mail" />

        <label htmlFor="senha">Senha</label>
        <input type="password" id="senha" placeholder="Digite sua senha" />

        <button className="login-button" type="submit">Entrar</button>
      </form>
    </div>
  );
}
